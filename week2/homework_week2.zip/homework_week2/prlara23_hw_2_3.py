'''
Pedro Ramirez
Class: CS 521 - Spring 1
Date: 01/26/2023
Homework Problem # 2_3
Description:
print formula and result of user's input
'''
n = int(input('Enter a number: '))

result = n**3 / n

# prints the formula and result
print(f'{n}**3/{n} = {result:.2f}')
