'''
Pedro Ramirez
Class: CS 521 - Spring 1
Date: 01/26/2023
Homework Problem # 2_4
Description:
print 0 if the number is even or 1 if odd
'''

number = input('Enter a number: ')
number = int(number)

# prints 0 if the number is even, 1 if the number is odd
print(number % 2)
